﻿using System;
using Nop.Core;

namespace Nop.Plugin.Payments.PayPing.Domains
{
    public class PayPingPayRecord : BaseEntity
    {
        public int Amount { get; set; }
        
        public string  ClientRefId { get; set; }
        public string  RefId { get; set; }
        public string PayCode { get; set; }
        public string OrderId { get; set; }
        public string CardNumber { get; set; }
        public bool IsPaid { get; set; }
        public DateTimeOffset PayDate { get; set; }
        
        
        public string PayerName { get; set; }
        public string PayerIdentity { get; set; }


    }
}