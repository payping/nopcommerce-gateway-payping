﻿using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Payments.PayPing.Components
{
    [ViewComponent(Name = "PaymentPayPingViewComponent")]
    public class PaymentPayPingViewComponent : NopViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View("~/Plugins/Payments.PayPing/Views/PaymentInfo.cshtml");
        }
    }
}
