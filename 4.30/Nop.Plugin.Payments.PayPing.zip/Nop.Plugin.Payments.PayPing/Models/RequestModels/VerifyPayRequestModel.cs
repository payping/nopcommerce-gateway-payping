﻿namespace Nop.Plugin.Payments.PayPing.Models.RequestModels
{
    public class VerifyPayRequestModel
    {
        public int Amount;
        public string RefId { get; set; }

    }
}