﻿namespace Nop.Plugin.Payments.PayPing.Models.ResponseModels
{
    public class CreatePayResponseModel
    {
        public string Code { get; set; }
    }
}