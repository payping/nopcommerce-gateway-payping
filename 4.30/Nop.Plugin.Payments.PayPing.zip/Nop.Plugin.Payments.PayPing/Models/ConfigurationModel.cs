﻿using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Payments.PayPing.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        [NopResourceDisplayName("Plugins.Payments.PayPing.Fields.PPToken")]
        public string PPToken { get; set; }
        public bool PPToken_OverrideForStore { get; set; }
        
        [NopResourceDisplayName("Plugins.Payments.PayPing.Fields.ReturnUrl")]
        public string ReturnUrl { get; set; }
        public bool ReturnUrl_OverrideForStore { get; set; }
        
        [NopResourceDisplayName("Plugins.Payments.PayPing.Fields.IsRial")]
        public bool IsRial { get; set; }
        public bool IsRial_OverrideForStore { get; set; }


    }
}