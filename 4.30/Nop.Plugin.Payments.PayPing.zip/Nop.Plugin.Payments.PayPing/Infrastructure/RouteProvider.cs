﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Payments.PayPing.Infrastructure
{
    public partial class RouteProvider : IRouteProvider
    {
       
        /// <summary>
        /// Register routes
        /// </summary>
        /// <param name="endpointRouteBuilder">Route builder</param>
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            //Verify Pay
            endpointRouteBuilder.MapControllerRoute("Plugin.Payments.PayPing.VerifyPay", "/Plugins/PaymentPayPing/VerifyPay",
                new { controller = "PaymentPayPing", action = "VerifyPay" });
            
            //Cancel
            endpointRouteBuilder.MapControllerRoute("Plugin.Payments.PayPing.CancelOrder", "/Plugins/PaymentPayPing/CancelOrder",
                new { controller = "PaymentPayPing", action = "CancelOrder" });
        }

        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority => -1;
    }
}