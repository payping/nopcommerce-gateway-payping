﻿using System;
using System.Threading.Tasks;
using Nop.Plugin.Payments.PayPing.Data;
using System.Threading.Tasks;
using LinqToDB;
using Nop.Data;
using Nop.Plugin.Payments.PayPing.Domains;

namespace Nop.Plugin.Payments.PayPing.Services
{
    
    public interface IPayPingPayService
    {
        Task InsertPay(PayPingPayRecord model);
        Task<PayPingPayRecord> GetPay(string clientRefId);
        Task UpdatePay(PayPingPayRecord model);
    }
    
    public class PayPingPayService : IPayPingPayService
    {
        private readonly IRepository<PayPingPayRecord> _repository;
        
        public PayPingPayService(IRepository<PayPingPayRecord> repository)
        {
            _repository = repository;
        }

        public async Task InsertPay(PayPingPayRecord model)
        {
            _repository.Insert(model);
        }

        public async Task<PayPingPayRecord> GetPay(string clientRefId)
        {
         return await _repository.Table.FirstOrDefaultAsync(x => x.ClientRefId == clientRefId);
        }

        public async Task UpdatePay(PayPingPayRecord model)
        {
            _repository.Update(model);
        }
    }
}