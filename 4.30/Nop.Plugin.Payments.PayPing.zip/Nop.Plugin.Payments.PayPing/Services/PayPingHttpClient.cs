﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using Nop.Core;
using Nop.Plugin.Payments.PayPing.Models.ExternalModels;
using Nop.Plugin.Payments.PayPing.Models.RequestModels;
using Nop.Plugin.Payments.PayPing.Models.ResponseModels;

namespace Nop.Plugin.Payments.PayPing.Services
{
    /// <summary>
    /// Represents the HTTP client to request PayPal services
    /// </summary>
    public partial class PayPingHttpClient
    {
        #region Fields

        string PayPing_PayURL = "https://api.payping.ir/v2/pay";
        private readonly HttpClient _httpClient;
        private readonly PayPingPaymentSettings _pingPaymentSettings;

        #endregion

        #region Ctor

        public PayPingHttpClient(HttpClient client, PayPingPaymentSettings pingPaymentSettings)
        {
            //configure client
            client.Timeout = TimeSpan.FromSeconds(20);
            client.DefaultRequestHeaders.Add(HeaderNames.Authorization, $"Bearer {pingPaymentSettings.PPToken}");

            _httpClient = client;
            _pingPaymentSettings = pingPaymentSettings;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Creates a Payment
        /// </summary>
        /// <param name="tx">TX</param>
        /// <returns>Payment Code</returns>
        public async Task<string> CreatePay(CreatePayRequestModel model)
        {
            if (_pingPaymentSettings.IsRial)
            {
                model.Amount = model.Amount / 10;
            }
            
            model.ReturnUrl = _pingPaymentSettings.ReturnUrl + "/Plugins/PaymentPayPing/VerifyPay";
            
            //Convert Request Model to Json String
            var data = JsonConvert.SerializeObject(model);
            var content = new StringContent(data, Encoding.UTF8, "application/json");

            //Send Create pay Request
            var response = await _httpClient.PostAsync(PayPing_PayURL, content);
            
            //Check if we ran into an Issue
            response.EnsureSuccessStatusCode();
            
            //Get Response data 
            string responseBody = await response.Content.ReadAsStringAsync();

            //Convert Response data to Model and get PayCode
            var createPayResult = JsonConvert.DeserializeObject<CreatePayResponseModel>(responseBody);
            return createPayResult.Code;
        }

        /// <summary>
        /// Verifies IPN
        /// </summary>
        /// <param name="formString">Form string</param>
        /// <returns>The asynchronous task whose result contains the IPN verification details</returns>
        public async Task<VerifyPayResponseModel> VerifyPay(PPVerifyPayHookModel model)
        {
            var verify_model = new VerifyPayRequestModel()
            {
                Amount = model.Amount,
                RefId = model.RefId
            };
            
            //Convert Request Model to Json String
            var data = JsonConvert.SerializeObject(verify_model);
            var content = new StringContent(data, Encoding.UTF8, "application/json");

            //Send Verify pay Request
            var response = await _httpClient.PostAsync(PayPing_PayURL + "/verify", content);
            
            //Check if we ran into an Issue
            response.EnsureSuccessStatusCode();
            
            //Get Response data 
            string responseBody = await response.Content.ReadAsStringAsync();

            //Convert Response data to Model and get our Payment Details
            var paymentDetails = JsonConvert.DeserializeObject<VerifyPayResponseModel>(responseBody);
            return paymentDetails;
        }

        #endregion
    }
}