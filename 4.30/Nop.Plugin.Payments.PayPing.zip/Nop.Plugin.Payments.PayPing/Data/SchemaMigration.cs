﻿using FluentMigrator;
using Nop.Data.Migrations;
using Nop.Plugin.Payments.PayPing.Domains;

namespace Nop.Plugin.Payments.PayPing.Data
{
    [SkipMigrationOnUpdate]
    [NopMigration("2020/11/17 09:30:17:6455422", "Payments.PayPing base schema")]
    public class SchemaMigration : AutoReversingMigration
    {
        protected IMigrationManager _migrationManager;

        public SchemaMigration(IMigrationManager migrationManager)
        {
            _migrationManager = migrationManager;
        }

        public override void Up()
        {
            _migrationManager.BuildTable<PayPingPayRecord>(Create);
        }
    }
}