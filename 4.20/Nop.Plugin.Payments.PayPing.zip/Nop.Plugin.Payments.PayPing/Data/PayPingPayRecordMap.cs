﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Nop.Data.Mapping;

namespace Nop.Plugin.Payments.PayPing.Data
{
  
    public class PayPingPayRecordMap : NopEntityTypeConfiguration<PayPingPayRecord>
    {
        /// <summary>
        /// Configures the entity
        /// </summary>
        /// <param name="builder">The builder to be used to configure the entity</param>
        public override void Configure(EntityTypeBuilder<PayPingPayRecord> builder)
        {
            builder.ToTable(nameof(PayPingPayRecord));
            //Map the primary key
            builder.HasKey(record => record.Id);

        }
    }
}