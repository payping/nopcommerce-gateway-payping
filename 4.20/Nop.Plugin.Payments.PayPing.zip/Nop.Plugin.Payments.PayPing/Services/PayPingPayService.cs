﻿using System;
using System.Threading.Tasks;
using Nop.Core.Data;
using Nop.Plugin.Payments.PayPing.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Nop.Plugin.Payments.PayPing.Services
{
    
    public interface IPayPingPayService
    {
        Task InsertPay(PayPingPayRecord model);
        Task<PayPingPayRecord> GetPay(string clientRefId);
        Task UpdatePay(PayPingPayRecord model);
    }
    
    public class PayPingPayService : IPayPingPayService
    {
        private readonly IRepository<PayPingPayRecord> _repository;
        private readonly PayPingPayRecordObjectContext _context;
        public PayPingPayService(IRepository<PayPingPayRecord> repository, PayPingPayRecordObjectContext context)
        {
            _repository = repository;
            _context = context;
        }

        public async Task InsertPay(PayPingPayRecord model)
        {
            _repository.Insert(model);
            await _context.SaveChangesAsync();
        }

        public async Task<PayPingPayRecord> GetPay(string clientRefId)
        {
         return await _repository.Table.FirstOrDefaultAsync(x => x.ClientRefId == clientRefId);
        }

        public async Task UpdatePay(PayPingPayRecord model)
        {
            _repository.Update(model);
            await _context.SaveChangesAsync();
        }
    }
}