﻿﻿namespace Nop.Plugin.Payments.PayPing.Models.ExternalModels
{
    public class PPVerifyPayHookModel
    {
        public int Amount { get; set; }
        public string RefId { get; set; }
        public string ClientRefId { get; set; }

    }
}