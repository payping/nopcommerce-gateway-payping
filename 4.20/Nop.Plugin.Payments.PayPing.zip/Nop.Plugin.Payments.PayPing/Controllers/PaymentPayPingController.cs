﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Nop.Core;
using Nop.Core.Domain.Orders;
using Nop.Core.Domain.Payments;
using Nop.Plugin.Payments.PayPing.Models;
using Nop.Plugin.Payments.PayPing.Models.ExternalModels;
using Nop.Plugin.Payments.PayPing.Models.RequestModels;
using Nop.Plugin.Payments.PayPing.Models.ResponseModels;
using Nop.Plugin.Payments.PayPing.Services;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Payments;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Payments.PayPing.Controllers
{
    public class PaymentPayPingController : BasePaymentController
    {
        #region Fields

        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IOrderProcessingService _orderProcessingService;
        private readonly IOrderService _orderService;
        private readonly IPaymentPluginManager _paymentPluginManager;
        private readonly IPermissionService _permissionService;
        private readonly ILocalizationService _localizationService;
        private readonly ILogger _logger;
        private readonly INotificationService _notificationService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly IWebHelper _webHelper;
        private readonly IWorkContext _workContext;
        private readonly ShoppingCartSettings _shoppingCartSettings;
        private readonly PayPingHttpClient _pingHttpClient;
        private readonly PayPingPaymentSettings _pingPaymentSettings;

        private readonly IPayPingPayService _pingPayService;

        #endregion

        #region Ctor

        public PaymentPayPingController(IGenericAttributeService genericAttributeService,
            IOrderProcessingService orderProcessingService,
            IOrderService orderService,
            IPaymentPluginManager paymentPluginManager,
            IPermissionService permissionService,
            ILocalizationService localizationService,
            ILogger logger,
            INotificationService notificationService,
            ISettingService settingService,
            IStoreContext storeContext,
            IWebHelper webHelper,
            IWorkContext workContext,
            ShoppingCartSettings shoppingCartSettings, PayPingHttpClient pingHttpClient, IPayPingPayService pingPayService, PayPingPaymentSettings pingPaymentSettings)
        {
            _genericAttributeService = genericAttributeService;
            _orderProcessingService = orderProcessingService;
            _orderService = orderService;
            _paymentPluginManager = paymentPluginManager;
            _permissionService = permissionService;
            _localizationService = localizationService;
            _logger = logger;
            _notificationService = notificationService;
            _settingService = settingService;
            _storeContext = storeContext;
            _webHelper = webHelper;
            _workContext = workContext;
            _shoppingCartSettings = shoppingCartSettings;
            _pingHttpClient = pingHttpClient;
            _pingPayService = pingPayService;
            _pingPaymentSettings = pingPaymentSettings;
        }

        #endregion

        #region Methods
        
        
  

        [AuthorizeAdmin]
        [Area(AreaNames.Admin)]
        public IActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var paypingPaymentSettings = _settingService.LoadSetting<PayPingPaymentSettings>(storeScope);

            var model = new ConfigurationModel
            {
                PPToken = paypingPaymentSettings.PPToken,
                ReturnUrl = paypingPaymentSettings.ReturnUrl,
                IsRial = paypingPaymentSettings.IsRial,
                ActiveStoreScopeConfiguration = storeScope

            };

            if (storeScope <= 0)
                return View("~/Plugins/Payments.PayPing/Views/Configure.cshtml", model);
            
            model.PPToken_OverrideForStore = _settingService.SettingExists(paypingPaymentSettings, x => x.PPToken, storeScope);
            model.ReturnUrl_OverrideForStore = _settingService.SettingExists(paypingPaymentSettings, x => x.ReturnUrl, storeScope);
            model.IsRial_OverrideForStore = _settingService.SettingExists(paypingPaymentSettings, x => x.IsRial, storeScope);


            return View("~/Plugins/Payments.PayPing/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [AuthorizeAdmin]
        [Area(AreaNames.Admin)]
        public IActionResult Configure(ConfigurationModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            if (!ModelState.IsValid)
                return Configure();

            //load settings for a chosen store scope
            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var paypingPaymentSettings = _settingService.LoadSetting<PayPingPaymentSettings>(storeScope);

            //save settings
            paypingPaymentSettings.PPToken = model.PPToken;
            paypingPaymentSettings.ReturnUrl = model.ReturnUrl;
            paypingPaymentSettings.IsRial = model.IsRial;

            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */
            _settingService.SaveSettingOverridablePerStore(paypingPaymentSettings, x => x.PPToken, model.PPToken_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paypingPaymentSettings, x => x.ReturnUrl, model.ReturnUrl_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(paypingPaymentSettings, x => x.IsRial, model.IsRial_OverrideForStore, storeScope, false);

            //now clear settings cache
            _settingService.ClearCache();

            _notificationService.SuccessNotification(_localizationService.GetResource("Admin.Plugins.Saved"));

            return Configure();
        }
 
        
        [HttpPost]
        [IgnoreAntiforgeryToken]
        [Route("/Plugins/PaymentPayPing/VerifyPay")]
        public async Task<IActionResult> VerifyPay(PPVerifyPayHookModel model)
        {
            var order = _orderService.GetOrderByGuid(Guid.Parse(model.ClientRefId));

            if (order == null)
                return RedirectToAction("Index", "Home", new { area = string.Empty });

            //validate order total
            
            var pay = await _pingPayService.GetPay(model.ClientRefId);
            
            if ( pay.Amount != order.OrderTotal)
            {
                var errorStr = $"PayPing VerifyPay. Returned order total {pay.Amount} doesn't equal order total {order.OrderTotal}. Order# {order.Id}.";
                //log
                _logger.Error(errorStr);
                //order note
                order.OrderNotes.Add(new OrderNote
                {
                    Note = errorStr,
                    DisplayToCustomer = false,
                    CreatedOnUtc = DateTime.UtcNow
                });
                _orderService.UpdateOrder(order);
            
                return RedirectToAction("Index", "Home", new { area = string.Empty });
            }

            //verify payment
            if (_pingPaymentSettings.IsRial)
            {
                model.Amount = pay.Amount / 10;
            }
            else
            {
                model.Amount = pay.Amount;
            }

            var peyment_details = await _pingHttpClient.VerifyPay(model);

            //update payment in our db
            pay.CardNumber = peyment_details.CardNumber;
            pay.IsPaid = true;
            pay.RefId = model.RefId;
            pay.Amount = (int)order.OrderTotal;
            pay.PayDate = DateTimeOffset.UtcNow;
            
            await _pingPayService.UpdatePay(pay);
            
            //Set order as paid
            _orderProcessingService.MarkOrderAsPaid(order);

            //order note
            order.OrderNotes.Add(new OrderNote
            {
                Note = $"RefId = {model.RefId} \n CardNumber = {peyment_details.CardNumber}",
                DisplayToCustomer = false,
                CreatedOnUtc = DateTime.UtcNow
            });
            order.CardNumber = peyment_details.CardNumber;
            
            _orderService.UpdateOrder(order);

            // return to confirm page
            return RedirectToRoute("CheckoutCompleted", new { orderId = order.Id });
        }


        public IActionResult CancelOrder()
        {
            var order = _orderService.SearchOrders(_storeContext.CurrentStore.Id,
                customerId: _workContext.CurrentCustomer.Id, pageSize: 1).FirstOrDefault();

            if (order != null)
                return RedirectToRoute("OrderDetails", new { orderId = order.Id });

            return RedirectToRoute("Homepage");
        }

        #endregion
    }
}