using Nop.Core.Configuration;

namespace Nop.Plugin.Payments.PayPing
{

    public class PayPingPaymentSettings : ISettings
    {
        
        public string PPToken { get; set; }
        public string ReturnUrl { get; set; }
        public bool IsRial { get; set; }

    }
}
